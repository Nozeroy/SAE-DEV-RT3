import java.io.*;
import java.net.*;

// Classe pour gérer la connexion au serveur
class ConnectionManager {
    private Socket socket; // Socket pour établir la connexion avec le serveur
    private BufferedReader reader; // Flux pour lire les données envoyées par le serveur
    private BufferedWriter writer; // Flux pour écrire des données vers le serveur

    // Méthode pour établir une connexion avec le serveur
    public void connect(String hostname, int port) throws IOException {
        socket = new Socket(hostname, port); // Création d'un socket connecté au serveur
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream())); // Initialisation du flux de lecture
        writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())); // Initialisation du flux d'écriture
    }

    // Méthode pour fermer la connexion et libérer les ressources
    public void close() throws IOException {
        if (reader != null) reader.close(); // Fermeture du flux de lecture
        if (writer != null) writer.close(); // Fermeture du flux d'écriture
        if (socket != null) socket.close(); // Fermeture du socket
    }

    // Getter pour obtenir le flux de lecture
    public BufferedReader getReader() {
        return reader;
    }

    // Getter pour obtenir le flux d'écriture
    public BufferedWriter getWriter() {
        return writer;
    }
}

// Classe pour gérer les messages reçus du serveur
class ServerMessageHandler {
    private BufferedReader reader; // Flux de lecture pour recevoir les messages du serveur

    // Constructeur prenant en paramètre le flux de lecture
    public ServerMessageHandler(BufferedReader reader) {
        this.reader = reader;
    }

    // Méthode pour recevoir un message du serveur
    public String receiveMessage() throws IOException {
        char[] buffer = new char[1024]; // Tampon pour stocker les caractères reçus
        int charsRead = reader.read(buffer); // Lecture des caractères depuis le flux

        if (charsRead == -1) {
            return null; // Retourne null si la connexion a été fermée par le serveur
        }

        // Conversion du tampon en chaîne de caractères, en supprimant les espaces inutiles
        return new String(buffer, 0, charsRead).trim();
    }
}

// Classe pour gérer les réponses envoyées au serveur
class ClientResponseHandler {
    private BufferedWriter writer; // Flux d'écriture pour envoyer des données au serveur

    // Constructeur prenant en paramètre le flux d'écriture
    public ClientResponseHandler(BufferedWriter writer) {
        this.writer = writer;
    }

    // Méthode pour envoyer un message au serveur
    public void sendMessage(String message) throws IOException {
        writer.write(message); // Écrit le message dans le flux
        writer.newLine(); // Ajoute une nouvelle ligne
        writer.flush(); // Envoie le contenu du flux immédiatement
    }
}

// Classe principale pour exécuter le client
public class ClientJava {
    public static void main(String[] args) {
        // Vérifie que les arguments nécessaires (hostname et port) sont fournis
        if (args.length < 2) {
            System.err.println("Usage: java ClientJava <hostname> <port>");
            return; // Arrête l'exécution si les arguments sont manquants
        }

        String hostname = args[0]; // Adresse du serveur
        int port = Integer.parseInt(args[1]); // Port du serveur

        ConnectionManager connectionManager = new ConnectionManager(); // Instance pour gérer la connexion

        try {
            // Établit la connexion au serveur
            connectionManager.connect(hostname, port);

            ServerMessageHandler serverHandler = new ServerMessageHandler(connectionManager.getReader()); // Gestion des messages reçus
            ClientResponseHandler responseHandler = new ClientResponseHandler(connectionManager.getWriter()); // Gestion des messages envoyés

            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in)); // Flux pour lire les entrées utilisateur
            String message;

            while (true) {
                System.out.println("En attente d'un message du serveur...");
                message = serverHandler.receiveMessage(); // Reçoit un message du serveur
                if (message == null || message.isEmpty()) { // Vérifie si la connexion a été fermée ou si le message est vide
                    System.out.println("Connexion fermée par le serveur.");
                    break;
                }
                System.out.println("Serveur: " + message); // Affiche le message reçu

                // Si le message se termine par ':' ou '?', le client est invité à répondre
                if (message.endsWith(":") || message.endsWith("?")) {
                    System.out.print("Vous: ");
                    message = userInput.readLine(); // Lit l'entrée utilisateur
                    responseHandler.sendMessage(message); // Envoie la réponse au serveur
                    System.out.println("Message envoyé au serveur.");
                }

                // Si le message est "terminé", la session se termine
                if (message.equalsIgnoreCase("terminé")) {
                    System.out.println("Fin de la session.");
                    break;
                }
            }

        } catch (IOException e) {
            // Gestion des erreurs liées aux entrées/sorties
            System.err.println("Erreur: " + e.getMessage());
        } finally {
            // Ferme la connexion et libère les ressources
            try {
                connectionManager.close();
            } catch (IOException e) {
                System.err.println("Erreur lors de la fermeture de la connexion: " + e.getMessage());
            }
        }
    }
}

