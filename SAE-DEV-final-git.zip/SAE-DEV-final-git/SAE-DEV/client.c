#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    int sock;
    struct sockaddr_in server_addr;
    struct hostent *server;
    char buffer[BUFFER_SIZE];
    
    if (argc < 3) {
        fprintf(stderr, "Usage: %s hostname port\n", argv[0]);
        exit(1);
    }
    
    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Erreur création socket");
        exit(1);
    }
    
    // Get server
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr, "Erreur: hôte inconnu\n");
        exit(1);
    }
    
    // Initialize server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    memcpy(&server_addr.sin_addr.s_addr, server->h_addr, server->h_length);
    server_addr.sin_port = htons(atoi(argv[2]));
    
    // Connect
    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Erreur connexion");
        exit(1);
    }
    
    // Communication loop
    while (1) {
        // Receive message from server
        memset(buffer, 0, BUFFER_SIZE);
        int n = recv(sock, buffer, BUFFER_SIZE-1, 0);
        if (n <= 0) break;
        
        printf("%s", buffer);
        
        // Get user input and send to server
        fgets(buffer, BUFFER_SIZE-1, stdin);
        n = send(sock, buffer, strlen(buffer), 0);
        if (n < 0) {
            perror("Erreur envoi");
            break;
        }
        
        // Check if contains "terminé"
        if (strstr(buffer, "terminé") != NULL) break;
    }
    
    close(sock);
    return 0;
}
