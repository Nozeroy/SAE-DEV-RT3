#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>
#include <dirent.h>

#define MAX_CLIENTS 10
#define BUFFER_SIZE 1024
#define MAX_STUDENTS 50

typedef struct {
    char etudid[10];
    char nip[10];
    char etat[2];
    char civilite[5];
    char nom[50];
    char nom_usuel[50];
    char prenom[50];
    char tp[5];
} Student;

typedef struct {
    int sock;
    struct sockaddr_in client_addr;
} client_info;

// Function to parse CSV file
int parse_csv(const char *filename, Student *students) {
    FILE *file = fopen(filename, "r");
    if (!file) return 0;
    
    char line[256];
    int count = 0;
    
    // Skip header
    fgets(line, sizeof(line), file);
    
    while (fgets(line, sizeof(line), file) && count < MAX_STUDENTS) {
        char *token = strtok(line, ";");
        if (token) strcpy(students[count].etudid, token);
        
        token = strtok(NULL, ";");
        if (token) strcpy(students[count].nip, token);
        
        token = strtok(NULL, ";");
        if (token) strcpy(students[count].etat, token);
        
        token = strtok(NULL, ";");
        if (token) strcpy(students[count].civilite, token);
        
        token = strtok(NULL, ";");
        if (token) strcpy(students[count].nom, token);
        
        token = strtok(NULL, ";");
        if (token) strcpy(students[count].nom_usuel, token);
        
        token = strtok(NULL, ";");
        if (token) strcpy(students[count].prenom, token);
        
        token = strtok(NULL, ";");
        if (token) {
            strcpy(students[count].tp, token);
            // Remove newline if present
            students[count].tp[strcspn(students[count].tp, "\n")] = 0;
        }
        
        count++;
    }
    
    fclose(file);
    return count;
}

void save_attendance(const char *classe, Student *students, int num_students, char *presence, char *filename_out) {
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    
    // Créer le nom du fichier et le stocker dans filename_out
    sprintf(filename_out, "appel-%s-%04d%02d%02d.txt", 
            classe, 
            tm->tm_year + 1900, 
            tm->tm_mon + 1, 
            tm->tm_mday);
    
    FILE *file = fopen(filename_out, "w");
    if (!file) return;
    
    fprintf(file, "Appel du %02d/%02d/%04d pour la classe %s\n\n",
            tm->tm_mday, tm->tm_mon + 1, tm->tm_year + 1900, classe);
            
    for (int i = 0; i < num_students; i++) {
        fprintf(file, "%s %s : %s\n", 
                students[i].nom, 
                students[i].prenom, 
                presence[i] == '1' ? "Présent" : "Absent");
    }
    
    fclose(file);
}

void *handle_client(void *arg) {
    client_info *info = (client_info *)arg;
    char buffer[BUFFER_SIZE];
    Student students[MAX_STUDENTS];
    char presence[MAX_STUDENTS] = {0};
    char classe[50] = {0};
    char filename_out[100] = {0};
    
    // Ask for class
    send(info->sock, "Entrez le nom de la classe (format RTxFx): ", 42, 0);
    int n = recv(info->sock, buffer, BUFFER_SIZE-1, 0);
    buffer[n] = '\0';
    
    // Nettoyer proprement le buffer et copier dans classe
    buffer[strcspn(buffer, "\r\n")] = 0;  // Supprime CR et LF
    strncpy(classe, buffer, sizeof(classe) - 1);
    classe[sizeof(classe) - 1] = '\0';    // Assure la terminaison
    
    // Construct CSV filename
    char csv_filename[100];
    sprintf(csv_filename, "CSV/%s.csv", classe);
    
    // Parse CSV
    int num_students = parse_csv(csv_filename, students);
    if (num_students == 0) {
        send(info->sock, "Classe non trouvée.\n", 20, 0);
        close(info->sock);
        free(info);
        return NULL;
    }
    
    // Do attendance for each student
    char msg[256];
    for (int i = 0; i < num_students; i++) {
        sprintf(msg, "%s %s est-il/elle présent(e)? (o/n): ",
                students[i].nom, students[i].prenom);
        send(info->sock, msg, strlen(msg), 0);
        
        n = recv(info->sock, buffer, BUFFER_SIZE-1, 0);
        buffer[n] = '\0';
        
        presence[i] = (buffer[0] == 'o' || buffer[0] == 'O') ? '1' : '0';
    }
    
    // Save attendance avec le nouveau paramètre filename_out
    save_attendance(classe, students, num_students, presence, filename_out);
    
    // Envoyer le message de confirmation avec le nom du fichier
    char completion_msg[150];
    sprintf(completion_msg, "Appel terminé et sauvegardé dans le fichier : %s\n", filename_out);
    send(info->sock, completion_msg, strlen(completion_msg), 0);
    
    close(info->sock);
    free(info);
    return NULL;
}

int main(int argc, char *argv[]) {
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    pthread_t thread_id;
    
    // Create socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock < 0) {
        perror("Erreur création socket");
        exit(1);
    }
    
    // Initialize server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(5001);
    
    // Bind
    if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Erreur bind");
        exit(1);
    }
    
    // Listen
    listen(server_sock, MAX_CLIENTS);
    printf("Serveur en écoute sur le port 5001...\n");
    
    while (1) {
        client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_len);
        if (client_sock < 0) {
            perror("Erreur accept");
            continue;
        }
        
        client_info *info = malloc(sizeof(client_info));
        info->sock = client_sock;
        info->client_addr = client_addr;
        
        if (pthread_create(&thread_id, NULL, handle_client, (void*)info) < 0) {
            perror("Erreur création thread");
            close(client_sock);
            free(info);
            continue;
        }
        
        pthread_detach(thread_id);
    }
    
    close(server_sock);
    return 0;
}
